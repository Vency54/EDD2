﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Cursos
{
    internal class Escola
    {
        private Curso[] cursos = new Curso[5];

        internal Curso[] Cursos { get => cursos; }


        public bool adicionarCurso(Curso curso)
        {
            for (int i = 0; i < cursos.Length; i++)
            {
                if (this.cursos[i] == null)
                {
                    this.cursos[i] = curso;
                    return true;
                }
            }
            return false;
        }

        public Curso pesquisarCurso(Curso curso)
        {
            for (int i = 0; i < this.cursos.Length; i++)
            {
                if (this.cursos[i].Id == curso.Id)
                {
                    return this.cursos[i];
                }
            }
            return null;
        }


        public bool removerCurso(Curso curso)
        {
            for (int i = 0; i < this.cursos.Length; i++)
            {

                if (this.cursos[i] != null)
                {
                    cursos[i] = null;
                    for (int j = i; j < cursos.Length - 1; j++)
                    {
                        this.cursos[j] = this.cursos[j + 1];
                    }
                    return true;
                }
            }

            return false;

        }
    }
}
