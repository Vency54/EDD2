﻿namespace Projeto_Cursos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int escolha;
            bool sair = false;
            Escola minhaEscola = new Escola();

            while (sair == false)
            {
                Console.WriteLine("Bem-vindo ao sistema de gerenciamento de Cursos!");

                Console.WriteLine("0. Sair");
                Console.WriteLine("1. Adicionar curso");
                Console.WriteLine("2. Pesquisar curso");
                Console.WriteLine("3. Remover curso");
                Console.WriteLine("4. Adicionar disciplina no curso");
                Console.WriteLine("5. Pesquisar disciplina");
                Console.WriteLine("6. Remover disciplina do curso");
                Console.WriteLine("7. Matricular aluno na disciplina");
                Console.WriteLine("8. Remover aluno da disciplina");
                Console.WriteLine("9. Pesquisar aluno");


                switch (escolha = int.Parse(Console.ReadLine()))
                {
                    case 0:
                        {
                            Console.WriteLine("Saindo do sistema...");
                            sair = true;
                            break;
                        }
                    case 1:
                        {
                            Console.WriteLine("Digite o ID do curso: ");
                            int id = int.Parse(Console.ReadLine());
                            Console.WriteLine("Digite a descrição do curso: ");
                            string descricao = Console.ReadLine();
                            Curso novoCurso = new Curso(id, descricao);
                            if (minhaEscola.adicionarCurso(novoCurso))
                            {
                                Console.WriteLine("Vendedor adicionado com sucesso!");
                            }
                            else
                            {
                                Console.WriteLine("Não foi possível adicionar o curso.");
                            }
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("Digite o ID do curso: ");
                            int id = int.Parse(Console.ReadLine());
                            Curso procurar = new Curso(id, " ");
                            Curso cursoEncontrado = minhaEscola.pesquisarCurso(procurar);
                            Console.WriteLine();
                            if (cursoEncontrado != null)
                            {
                                Console.WriteLine("Curso encontrado:");
                                Console.WriteLine($"Id: {cursoEncontrado.Id}");
                                Console.WriteLine($"Descrição: {cursoEncontrado.Descricao}");

                            }
                            else
                            {
                                Console.WriteLine("Curso não encontrado.");
                            }
                        }
                        break;
                    case 3:
                        {
                            Console.WriteLine("Digite o ID do Curso: ");
                            int id = int.Parse(Console.ReadLine());
                            Curso procurar = new Curso(id, " ");
                            bool achou = minhaEscola.removerCurso(procurar);
                            if (achou)
                            {
                                Console.WriteLine("Curso excluído com sucesso!");
                            }
                            else
                            {
                                Console.WriteLine("Não foi possível excluir o Curso.");
                            }
                        }
                        break;
                    case 4:
                        {
                            Console.WriteLine("Digite o ID do Curso: ");
                            int id = int.Parse(Console.ReadLine());
                            Curso procurar = new Curso(id, " ");
                            Curso cursoEncontrado = minhaEscola.pesquisarCurso(procurar);
                            if (cursoEncontrado != null)
                            {
                                Console.WriteLine("Digite o Id da disciplina: ");
                                int idDisc = int.Parse(Console.ReadLine());
                                Console.WriteLine("Digite a quantidade de descrição: ");
                                string descricao = Console.ReadLine();
                                Disciplina novaDisciplina = new Disciplina(idDisc, descricao);
                                cursoEncontrado.adicionarDisciplina(novaDisciplina);
                            }
                            else
                            {
                                Console.WriteLine("Vendedor não encontrado para registrar venda.");
                            }
                        }
                        break;
                    case 5:
                        {
                            Console.WriteLine("Digite o ID do Disciplina: ");
                            int id = int.Parse(Console.ReadLine());
                            Disciplina procurar = new Disciplina(id, " ");
                            foreach (Curso c in minhaEscola.Cursos)
                            {
                                if (c != null)
                                {
                                    Disciplina disciplinaEncontrada = c.pesquisarDisciplina(procurar);
                                    if (disciplinaEncontrada != null)
                                    {
                                        Console.WriteLine("Disciplina encontrada:");
                                        Console.WriteLine($"Id: {disciplinaEncontrada.Id}");
                                        Console.WriteLine($"Descrição: {disciplinaEncontrada.Descricao}");
                                    }
                                }
                            }
                        }
                        break;


                    case 6:
                        {
                            Console.WriteLine("Digite o ID do Curso: ");
                            int id = int.Parse(Console.ReadLine());
                            Console.WriteLine("Digite o ID do Disciplina: ");
                            int idDisc = int.Parse(Console.ReadLine());
                            Disciplina procurar = new Disciplina(idDisc, " ");
                            bool cursoEncontrado = false;
                            foreach (Curso c in minhaEscola.Cursos)
                            {
                                if (c != null && c.Id == id)
                                {
                                    cursoEncontrado = true;
                                    bool removido = c.removerDisciplina(procurar);
                                    if (removido)
                                    {
                                        Console.WriteLine("Disciplina removida com sucesso!");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Não foi possível remover a disciplina.");
                                    }
                                }
                                if (!cursoEncontrado)
                                {
                                    Console.WriteLine("Curso não encontrado.");
                                }
                            }
                        }
                        break;

                    case 7: {
                            Console.WriteLine("Digite o ID do Disciplina: ");
                            int id = int.Parse(Console.ReadLine());
                            Disciplina procurar = new Disciplina(id, " ");
                            foreach (Curso c in minhaEscola.Cursos)
                            {
                                if (c != null)
                                {
                                    Disciplina disciplinaEncontrada = c.pesquisarDisciplina(procurar);
                                    if (disciplinaEncontrada != null)
                                    {
                                        Console.WriteLine("Digite o ID do Aluno: ");
                                        int idAluno = int.Parse(Console.ReadLine());
                                        Console.WriteLine("Digite o nome do Aluno: ");
                                        string nomeAluno = Console.ReadLine();
                                        Aluno novoAluno = new Aluno(idAluno, nomeAluno);
                                        if (novoAluno.podeMatricular(c))
                                        {
                                            bool matriculado = disciplinaEncontrada.matricularAluno(novoAluno);
                                            if (matriculado)
                                            {
                                                Console.WriteLine("Aluno matriculado com sucesso!");
                                            }
                                            else
                                            {
                                                Console.WriteLine("Não foi possível matricular o aluno.");
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine("O aluno já está matriculado em uma disciplina deste curso.");
                                        }
                                        disciplinaEncontrada.matricularAluno(novoAluno);
                                    }
                                }
                            }

                        }
                        break;
                    case 8: {
                            Console.WriteLine("Digite o ID do Disciplina: ");
                            int id = int.Parse(Console.ReadLine());
                            Disciplina procurar = new Disciplina(id, " ");
                            foreach (Curso c in minhaEscola.Cursos)
                            {
                                if (c != null)
                                {
                                    Disciplina disciplinaEncontrada = c.pesquisarDisciplina(procurar);
                                    if (disciplinaEncontrada != null)
                                    {
                                        Console.WriteLine("Digite o ID do Aluno: ");
                                        int idAluno = int.Parse(Console.ReadLine());
                                        Console.WriteLine("Digite o nome do Aluno: ");
                                        string nomeAluno = Console.ReadLine();
                                        Aluno novoAluno = new Aluno(idAluno, nomeAluno);
                                
                                           bool matriculado = disciplinaEncontrada.desmatricularAluno(novoAluno);
                                            if (matriculado)
                                            {
                                                Console.WriteLine("Aluno removido com sucesso!");
                                            }
                                            else
                                            {
                                                Console.WriteLine("Não foi possível remover o aluno.");
                                            }
                                        }
                                    }
                                }
                            }
                        
                        break;
                    case 9:
                        {
                            Console.WriteLine("Digite o ID do Curso: ");
                            int idCurso = int.Parse(Console.ReadLine());
                            Curso procurar = new Curso(idCurso, " ");
                            Curso cursoEncontrado = minhaEscola.pesquisarCurso(procurar);
                            if (cursoEncontrado != null)
                            {
                                Console.WriteLine("Digite o ID do Aluno: ");
                                int idAluno = int.Parse(Console.ReadLine());
                                bool achou = false;
                                foreach (Disciplina d in cursoEncontrado.Disciplinas)
                                {
                                    if (d.Alunos != null)
                                    {
                                        Aluno alunoEncontrado = d.pesquisarAluno(idAluno);
                                        if (alunoEncontrado != null)
                                        {
                                            achou = true;
                                            Console.WriteLine("Aluno encontrado:");
                                            Console.WriteLine($"Id: {alunoEncontrado.Id}");
                                            Console.WriteLine($"Nome: {alunoEncontrado.Nome}");
                                            break;
                                        }
                                    }
                                }
                                if (achou == false)
                                {
                                    Console.WriteLine("Aluno não encontrado.");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Curso não encontrado.");
                            }
                        }
                        break;
                    default:
                        Console.WriteLine("Opção inválida.");
                        break;
                }

                Console.WriteLine("Pressione qualquer tecla para continuar...");
                Console.ReadLine();
                Console.Clear();
            }
        }
    }
}